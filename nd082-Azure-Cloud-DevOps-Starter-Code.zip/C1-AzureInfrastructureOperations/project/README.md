# Azure Infrastructure Operations Project: Deploying a scalable IaaS web server in Azure

### Introduction
For this project, you will write a Packer template and a Terraform template to deploy a customizable, scalable web server in Azure.

### Getting Started
1. Clone this repository

2. Create your infrastructure as code

3. Update this README to reflect how someone would use your code.

### Dependencies
1. Create an [Azure Account](https://portal.azure.com) 
2. Install the [Azure command line interface](https://docs.microsoft.com/en-us/cli/azure/install-azure-cli?view=azure-cli-latest)
3. Install [Packer](https://www.packer.io/downloads)
4. Install [Terraform](https://www.terraform.io/downloads.html)

### Instructions
##### Log in to Azure
```
az login
```

---
##### Create a policy to deny resources that do not have tags

policy.json
```
{
	"if": {
      "anyOf": [
        {
          "field": "tags",
          "exists": "false"
        }
      ]
    },
    "then": {
      "effect": "deny"
    }
}
```

Apply the policy
```
az policy definition create --name 'no-tags-deny' --display-name 'Reject All Without Tags' --description 'This policy will deny the creation of resources without tags' --rules 'policy.json' --mode All
```

Verify the policy was applied
```
az policy assignment list
```

---
##### Create an image to be used in your infrastructure

Make sure that you have the azure plugin installed. 
```
packer plugins install github.com/hashicorp/azure
```

After completing the configuration for your packer image template.  You can build your packer image
```
packer build <path to json config file>
```

Check the [Azure Portal](https://portal.azure.com) to verify that the image was created. 

---

Create your infrastructure

Initialize the project folder. 
```
terraform init
```

Make adjustments to the vars file. 
vars.tf
```
variable "resource_tag_id"{
  description = "Provide a resource ID to apply to all resources in this build"
}  

variable "prefix" {
  description = "The prefix which should be used for all resources in this example"
}  

variable "location" {
  description = "The Azure Region in which all resources in this example should be created."
}  

variable "admin_username" {
  description = "The admin username for the VM being created."
} 

variable "admin_password" {
  description = "The password for the VM being created."
}
  
variable "server_ct"{
  default = "2"
} 

variable "image_id"{
  default = "<image id>"

}

```


- **resource_tag_id**: is a tag that will be automatically applied. 
- **prefix**: is an identifier for this build
- **admin_username**: admin user for the VMs that are created
- **admin_password**: password for the admin user on the VMs that are created
- **server_list**: list of server names for multiple VMs
- server_ct: amount of servers to create
- image_id: this is the name of the image that will be used to build the new VMs that you created with packer

Make a plan for your infrastructure build. This will provide a a decent picture of the new state of your infrastructure. 
```
terraform plan -out solution.plan
```

Once the plan runs without any errors, you can execute the plan
```
terraform apply solution.plan
```

After the plan has been executed, verify that the infrastructure is correct using the Azure CLI or the Azure Portal.

Destroy the infrastructure
```
terraform destroy
```

---

Output from packer build
```
packer build server.json
azure-arm: output will be in this color.

==> azure-arm: Running builder ...
    azure-arm: Creating Azure Resource Manager (ARM) client ...
    azure-arm: ARM Client successfully created
==> azure-arm: Getting source image id for the deployment ...
==> azure-arm:  -> SourceImageName: '/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/providers/Microsoft.Compute/locations/East US/publishers/Canonical/ArtifactTypes/vmimage/offers/UbuntuServer/skus/18.04-LTS/versions/latest'
==> azure-arm: Creating resource group ...
==> azure-arm:  -> ResourceGroupName : 'pkr-Resource-Group-wte6pmhn1j'
==> azure-arm:  -> Location          : 'East US'
==> azure-arm:  -> Tags              :
==> azure-arm: Validating deployment template ...
==> azure-arm:  -> ResourceGroupName : 'pkr-Resource-Group-wte6pmhn1j'
==> azure-arm:  -> DeploymentName    : 'pkrdpwte6pmhn1j'
==> azure-arm: Deploying deployment template ...
==> azure-arm:  -> ResourceGroupName : 'pkr-Resource-Group-wte6pmhn1j'
==> azure-arm:  -> DeploymentName    : 'pkrdpwte6pmhn1j'
==> azure-arm: Getting the VM's IP address ...
==> azure-arm:  -> ResourceGroupName   : 'pkr-Resource-Group-wte6pmhn1j'
==> azure-arm:  -> PublicIPAddressName : 'pkripwte6pmhn1j'
==> azure-arm:  -> NicName             : 'pkrniwte6pmhn1j'
==> azure-arm:  -> Network Connection  : 'PublicEndpoint'
==> azure-arm:  -> IP Address          : '172.203.146.28'
==> azure-arm: Waiting for SSH to become available...
==> azure-arm: Connected to SSH!
==> azure-arm: Provisioning with shell script: C:\Users\dez\AppData\Local\Temp\packer-shell1482101680
==> azure-arm: + echo Hello, World!
==> azure-arm: + echo [Unit]
==> azure-arm: + echo Description=HTTP Hello World
==> azure-arm: + echo After=network.target
==> azure-arm: + echo StartLimitIntervalSec=0
==> azure-arm: + echo [Service]
==> azure-arm: + echo Type=simple
==> azure-arm: + echo Restart=always
==> azure-arm: + echo RestartSec=1
==> azure-arm: + echo User=packer
==> azure-arm: + echo ExecStart=/usr/bin/nohup /bin/busybox httpd -f -p 8080 -h /home/packer
==> azure-arm: + echo [Install]
==> azure-arm: + echo WantedBy=multi-user.target
==> azure-arm: + sudo mv http.service /etc/systemd/system
==> azure-arm: + sudo chown root:root /etc/systemd/system/http.service
==> azure-arm: + sudo chmod 755 /etc/systemd/system/http.service
==> azure-arm: + sudo systemctl enable http
==> azure-arm: Created symlink /etc/systemd/system/multi-user.target.wants/http.service → /etc/systemd/system/http.service.
==> azure-arm: Querying the machine's properties ...
==> azure-arm:  -> ResourceGroupName : 'pkr-Resource-Group-wte6pmhn1j'
==> azure-arm:  -> ComputeName       : 'pkrvmwte6pmhn1j'
==> azure-arm:  -> Managed OS Disk   : '/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/pkr-Resource-Group-wte6pmhn1j/providers/Microsoft.Compute/disks/pkroswte6pmhn1j'
==> azure-arm: Querying the machine's additional disks properties ...
==> azure-arm:  -> ResourceGroupName : 'pkr-Resource-Group-wte6pmhn1j'
==> azure-arm:  -> ComputeName       : 'pkrvmwte6pmhn1j'
==> azure-arm: Powering off machine ...
==> azure-arm:  -> ResourceGroupName : 'pkr-Resource-Group-wte6pmhn1j'
==> azure-arm:  -> ComputeName       : 'pkrvmwte6pmhn1j'
==> azure-arm:  -> Compute ResourceGroupName : 'pkr-Resource-Group-wte6pmhn1j'
==> azure-arm:  -> Compute Name              : 'pkrvmwte6pmhn1j'
==> azure-arm:  -> Compute Location          : 'East US'
==> azure-arm: Generalizing machine ...
==> azure-arm: Capturing image ...
==> azure-arm:  -> Image ResourceGroupName   : 'Azuredevops'
==> azure-arm:  -> Image Name                : 'c1_packer_image'
==> azure-arm:  -> Image Location            : 'East US'
==> azure-arm:
==> azure-arm: Deleting Virtual Machine deployment and its attached resources...
==> azure-arm: Deleted -> pkrvmwte6pmhn1j : 'Microsoft.Compute/virtualMachines'
==> azure-arm: Deleted -> pkrniwte6pmhn1j : 'Microsoft.Network/networkInterfaces'
==> azure-arm: Deleted -> pkrvnwte6pmhn1j : 'Microsoft.Network/virtualNetworks'
==> azure-arm: Deleted -> pkripwte6pmhn1j : 'Microsoft.Network/publicIPAddresses'
==> azure-arm: Deleted -> Microsoft.Compute/disks : '/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/pkr-Resource-Group-wte6pmhn1j/providers/Microsoft.Compute/disks/pkroswte6pmhn1j'
==> azure-arm: Removing the created Deployment object: 'pkrdpwte6pmhn1j'
==> azure-arm:
==> azure-arm: Cleanup requested, deleting resource group ...
==> azure-arm: Resource group has been deleted.
Build 'azure-arm' finished after 2 minutes 35 seconds.

==> Wait completed after 2 minutes 35 seconds

==> Builds finished. The artifacts of successful builds are:
--> azure-arm: Azure.ResourceManagement.VMImage:

OSType: Linux
ManagedImageResourceGroupName: Azuredevops
ManagedImageName: c1_packer_image
ManagedImageId: /subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops/providers/Microsoft.Compute/images/c1_packer_image
ManagedImageLocation: East US
```

Output from plan
```
$ terraform plan -out solution.plan
var.admin_password
  The password for the VM being created.

  Enter a value: 1q2w3e4r!Q@W#E$R

var.admin_username
  The admin username for the VM being created.

  Enter a value: dezebuwa

data.azurerm_resource_group.main: Reading...
data.azurerm_resource_group.main: Read complete after 0s [id=/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops]

Terraform used the selected providers to generate the following execution plan. Resource actions are indicated with the following symbols:
  + create

Terraform will perform the following actions:

  # azurerm_availability_set.main will be created
  + resource "azurerm_availability_set" "main" {
      + id                           = (known after apply)
      + location                     = "westeurope"
      + managed                      = true
      + name                         = "c1-prj-availabilitySet"
      + platform_fault_domain_count  = 2
      + platform_update_domain_count = 5
      + resource_group_name          = "Azuredevops"
      + tags                         = {
          + "resource_tag_id" = "c1-prj-res"
        }
    }

  # azurerm_lb.main will be created
  + resource "azurerm_lb" "main" {
      + id                   = (known after apply)
      + location             = "westeurope"
      + name                 = "c1-prj-lb"
      + private_ip_address   = (known after apply)
      + private_ip_addresses = (known after apply)
      + resource_group_name  = "Azuredevops"
      + sku                  = "Basic"
      + sku_tier             = "Regional"
      + tags                 = {
          + "resource_tag_id" = "c1-prj-res"
        }

      + frontend_ip_configuration {
          + gateway_load_balancer_frontend_ip_configuration_id = (known after apply)
          + id                                                 = (known after apply)
          + inbound_nat_rules                                  = (known after apply)
          + load_balancer_rules                                = (known after apply)
          + name                                               = "PublicIPAddress"
          + outbound_rules                                     = (known after apply)
          + private_ip_address                                 = (known after apply)
          + private_ip_address_allocation                      = (known after apply)
          + private_ip_address_version                         = (known after apply)
          + public_ip_address_id                               = (known after apply)
          + public_ip_prefix_id                                = (known after apply)
          + subnet_id                                          = (known after apply)
        }
    }

  # azurerm_lb_backend_address_pool.main will be created
  + resource "azurerm_lb_backend_address_pool" "main" {
      + backend_ip_configurations = (known after apply)
      + id                        = (known after apply)
      + inbound_nat_rules         = (known after apply)
      + load_balancing_rules      = (known after apply)
      + loadbalancer_id           = (known after apply)
      + name                      = "c1-prj-beap"
      + outbound_rules            = (known after apply)
    }

  # azurerm_linux_virtual_machine.main[0] will be created
  + resource "azurerm_linux_virtual_machine" "main" {
      + admin_password                                         = (sensitive value)
      + admin_username                                         = "dezebuwa"
      + allow_extension_operations                             = true
      + availability_set_id                                    = (known after apply)
      + bypass_platform_safety_checks_on_user_schedule_enabled = false
      + computer_name                                          = (known after apply)
      + disable_password_authentication                        = false
      + disk_controller_type                                   = (known after apply)
      + extensions_time_budget                                 = "PT1H30M"
      + id                                                     = (known after apply)
      + location                                               = "westeurope"
      + max_bid_price                                          = -1
      + name                                                   = "c1-prj-vm-0"
      + network_interface_ids                                  = (known after apply)
      + patch_assessment_mode                                  = "ImageDefault"
      + patch_mode                                             = "ImageDefault"
      + platform_fault_domain                                  = -1
      + priority                                               = "Regular"
      + private_ip_address                                     = (known after apply)
      + private_ip_addresses                                   = (known after apply)
      + provision_vm_agent                                     = true
      + public_ip_address                                      = (known after apply)
      + public_ip_addresses                                    = (known after apply)
      + resource_group_name                                    = "Azuredevops"
      + size                                                   = "Standard_D2s_v3"
      + source_image_id                                        = "/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops/providers/Microsoft.Compute/images/c1_packer_image"
      + virtual_machine_id                                     = (known after apply)
      + vm_agent_platform_updates_enabled                      = false

      + os_disk {
          + caching                   = "ReadWrite"
          + disk_size_gb              = (known after apply)
          + name                      = (known after apply)
          + storage_account_type      = "Standard_LRS"
          + write_accelerator_enabled = false
        }
    }

  # azurerm_linux_virtual_machine.main[1] will be created
  + resource "azurerm_linux_virtual_machine" "main" {
      + admin_password                                         = (sensitive value)
      + admin_username                                         = "dezebuwa"
      + allow_extension_operations                             = true
      + availability_set_id                                    = (known after apply)
      + bypass_platform_safety_checks_on_user_schedule_enabled = false
      + computer_name                                          = (known after apply)
      + disable_password_authentication                        = false
      + disk_controller_type                                   = (known after apply)
      + extensions_time_budget                                 = "PT1H30M"
      + id                                                     = (known after apply)
      + location                                               = "westeurope"
      + max_bid_price                                          = -1
      + name                                                   = "c1-prj-vm-1"
      + network_interface_ids                                  = (known after apply)
      + patch_assessment_mode                                  = "ImageDefault"
      + patch_mode                                             = "ImageDefault"
      + platform_fault_domain                                  = -1
      + priority                                               = "Regular"
      + private_ip_address                                     = (known after apply)
      + private_ip_addresses                                   = (known after apply)
      + provision_vm_agent                                     = true
      + public_ip_address                                      = (known after apply)
      + public_ip_addresses                                    = (known after apply)
      + resource_group_name                                    = "Azuredevops"
      + size                                                   = "Standard_D2s_v3"
      + source_image_id                                        = "/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops/providers/Microsoft.Compute/images/c1_packer_image"
      + virtual_machine_id                                     = (known after apply)
      + vm_agent_platform_updates_enabled                      = false

      + os_disk {
          + caching                   = "ReadWrite"
          + disk_size_gb              = (known after apply)
          + name                      = (known after apply)
          + storage_account_type      = "Standard_LRS"
          + write_accelerator_enabled = false
        }
    }

  # azurerm_network_interface.main[0] will be created
  + resource "azurerm_network_interface" "main" {
      + applied_dns_servers           = (known after apply)
      + dns_servers                   = (known after apply)
      + enable_accelerated_networking = false
      + enable_ip_forwarding          = false
      + id                            = (known after apply)
      + internal_dns_name_label       = (known after apply)
      + internal_domain_name_suffix   = (known after apply)
      + location                      = "westeurope"
      + mac_address                   = (known after apply)
      + name                          = "c1-prj-nic0"
      + private_ip_address            = (known after apply)
      + private_ip_addresses          = (known after apply)
      + resource_group_name           = "Azuredevops"
      + tags                          = {
          + "resource_tag_id" = "c1-prj-res"
        }
      + virtual_machine_id            = (known after apply)

      + ip_configuration {
          + gateway_load_balancer_frontend_ip_configuration_id = (known after apply)
          + name                                               = "internal"
          + primary                                            = (known after apply)
          + private_ip_address                                 = (known after apply)
          + private_ip_address_allocation                      = "Dynamic"
          + private_ip_address_version                         = "IPv4"
          + subnet_id                                          = (known after apply)
        }
    }

  # azurerm_network_interface.main[1] will be created
  + resource "azurerm_network_interface" "main" {
      + applied_dns_servers           = (known after apply)
      + dns_servers                   = (known after apply)
      + enable_accelerated_networking = false
      + enable_ip_forwarding          = false
      + id                            = (known after apply)
      + internal_dns_name_label       = (known after apply)
      + internal_domain_name_suffix   = (known after apply)
      + location                      = "westeurope"
      + mac_address                   = (known after apply)
      + name                          = "c1-prj-nic1"
      + private_ip_address            = (known after apply)
      + private_ip_addresses          = (known after apply)
      + resource_group_name           = "Azuredevops"
      + tags                          = {
          + "resource_tag_id" = "c1-prj-res"
        }
      + virtual_machine_id            = (known after apply)

      + ip_configuration {
          + gateway_load_balancer_frontend_ip_configuration_id = (known after apply)
          + name                                               = "internal"
          + primary                                            = (known after apply)
          + private_ip_address                                 = (known after apply)
          + private_ip_address_allocation                      = "Dynamic"
          + private_ip_address_version                         = "IPv4"
          + subnet_id                                          = (known after apply)
        }
    }

  # azurerm_network_interface_backend_address_pool_association.main[0] will be created
  + resource "azurerm_network_interface_backend_address_pool_association" "main" {
      + backend_address_pool_id = (known after apply)
      + id                      = (known after apply)
      + ip_configuration_name   = "internal"
      + network_interface_id    = (known after apply)
    }

  # azurerm_network_interface_backend_address_pool_association.main[1] will be created
  + resource "azurerm_network_interface_backend_address_pool_association" "main" {
      + backend_address_pool_id = (known after apply)
      + id                      = (known after apply)
      + ip_configuration_name   = "internal"
      + network_interface_id    = (known after apply)
    }

  # azurerm_network_security_group.main will be created
  + resource "azurerm_network_security_group" "main" {
      + id                  = (known after apply)
      + location            = "westeurope"
      + name                = "c1-prj-nsg"
      + resource_group_name = "Azuredevops"
      + security_rule       = (known after apply)
      + tags                = {
          + "resource_tag_id" = "c1-prj-res"
        }
    }

  # azurerm_network_security_rule.AllowInternalInbound will be created
  + resource "azurerm_network_security_rule" "AllowInternalInbound" {
      + access                       = "Allow"
      + destination_address_prefixes = [
          + "10.0.0.0/24",
        ]
      + destination_port_range       = "*"
      + direction                    = "Inbound"
      + id                           = (known after apply)
      + name                         = "AllowInternalInbound"
      + network_security_group_name  = "c1-prj-nsg"
      + priority                     = 1001
      + protocol                     = "*"
      + resource_group_name          = "Azuredevops"
      + source_address_prefixes      = [
          + "10.0.0.0/24",
        ]
      + source_port_range            = "*"
    }

  # azurerm_network_security_rule.AllowInternalOutbound will be created
  + resource "azurerm_network_security_rule" "AllowInternalOutbound" {
      + access                      = "Allow"
      + destination_address_prefix  = "*"
      + destination_port_range      = "*"
      + direction                   = "Outbound"
      + id                          = (known after apply)
      + name                        = "AllowInternalOutbound"
      + network_security_group_name = "c1-prj-nsg"
      + priority                    = 1002
      + protocol                    = "*"
      + resource_group_name         = "Azuredevops"
      + source_address_prefixes     = [
          + "10.0.0.0/24",
        ]
      + source_port_range           = "*"
    }

  # azurerm_network_security_rule.AllowLoadBalancerInbound will be created
  + resource "azurerm_network_security_rule" "AllowLoadBalancerInbound" {
      + access                       = "Allow"
      + destination_address_prefixes = [
          + "10.0.0.0/24",
        ]
      + destination_port_range       = "*"
      + direction                    = "Inbound"
      + id                           = (known after apply)
      + name                         = "AllowLoadBalancerInbound"
      + network_security_group_name  = "c1-prj-nsg"
      + priority                     = 1003
      + protocol                     = "*"
      + resource_group_name          = "Azuredevops"
      + source_address_prefixes      = [
          + "10.0.0.0/24",
        ]
      + source_port_range            = "*"
    }

  # azurerm_network_security_rule.DenyInboundInternet will be created
  + resource "azurerm_network_security_rule" "DenyInboundInternet" {
      + access                      = "Deny"
      + destination_address_prefix  = "*"
      + destination_port_range      = "*"
      + direction                   = "Inbound"
      + id                          = (known after apply)
      + name                        = "DenyInboundInternet"
      + network_security_group_name = "c1-prj-nsg"
      + priority                    = 1000
      + protocol                    = "*"
      + resource_group_name         = "Azuredevops"
      + source_address_prefix       = "*"
      + source_port_range           = "*"
    }

  # azurerm_public_ip.main will be created
  + resource "azurerm_public_ip" "main" {
      + allocation_method       = "Static"
      + ddos_protection_mode    = "VirtualNetworkInherited"
      + fqdn                    = (known after apply)
      + id                      = (known after apply)
      + idle_timeout_in_minutes = 4
      + ip_address              = (known after apply)
      + ip_version              = "IPv4"
      + location                = "westeurope"
      + name                    = "c1-prj-publicIP"
      + resource_group_name     = "Azuredevops"
      + sku                     = "Basic"
      + sku_tier                = "Regional"
      + tags                    = {
          + "resource_tag_id" = "c1-prj-res"
        }
    }

  # azurerm_subnet.internal will be created
  + resource "azurerm_subnet" "internal" {
      + address_prefixes                               = [
          + "10.0.0.0/24",
        ]
      + enforce_private_link_endpoint_network_policies = (known after apply)
      + enforce_private_link_service_network_policies  = (known after apply)
      + id                                             = (known after apply)
      + name                                           = "internal"
      + private_endpoint_network_policies              = (known after apply)
      + private_endpoint_network_policies_enabled      = (known after apply)
      + private_link_service_network_policies_enabled  = (known after apply)
      + resource_group_name                            = "Azuredevops"
      + virtual_network_name                           = "c1-prj-network"
    }

  # azurerm_virtual_network.main will be created
  + resource "azurerm_virtual_network" "main" {
      + address_space       = [
          + "10.0.0.0/24",
        ]
      + dns_servers         = (known after apply)
      + guid                = (known after apply)
      + id                  = (known after apply)
      + location            = "westeurope"
      + name                = "c1-prj-network"
      + resource_group_name = "Azuredevops"
      + subnet              = (known after apply)
      + tags                = {
          + "resource_tag_id" = "c1-prj-res"
        }
    }

Plan: 17 to add, 0 to change, 0 to destroy.

Changes to Outputs:
  + name = [
      + "c1-prj-vm-0",
      + "c1-prj-vm-1",
    ]

─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────── 

Saved the plan to: solution.plan
```


Output from apply
```
$ terraform apply solution.plan
azurerm_network_security_group.main: Creating...
azurerm_virtual_network.main: Creating...
azurerm_availability_set.main: Creating...
azurerm_public_ip.main: Creating...
azurerm_availability_set.main: Creation complete after 3s [id=/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops/providers/Microsoft.Compute/availabilitySets/c1-prj-availabilitySet]
azurerm_public_ip.main: Creation complete after 4s [id=/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops/providers/Microsoft.Network/publicIPAddresses/c1-prj-publicIP]
azurerm_lb.main: Creating...
azurerm_network_security_group.main: Creation complete after 5s [id=/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops/providers/Microsoft.Network/networkSecurityGroups/c1-prj-nsg]
azurerm_network_security_rule.DenyInboundInternet: Creating...
azurerm_virtual_network.main: Creation complete after 7s [id=/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops/providers/Microsoft.Network/virtualNetworks/c1-prj-network]
azurerm_subnet.internal: Creating...
azurerm_network_security_rule.DenyInboundInternet: Creation complete after 2s [id=/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops/providers/Microsoft.Network/networkSecurityGroups/c1-prj-nsg/securityRules/DenyInboundInternet]
azurerm_subnet.internal: Creation complete after 5s [id=/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops/providers/Microsoft.Network/virtualNetworks/c1-prj-network/subnets/internal]
azurerm_network_security_rule.AllowInternalInbound: Creating...
azurerm_network_security_rule.AllowLoadBalancerInbound: Creating...
azurerm_network_interface.main[0]: Creating...
azurerm_network_security_rule.AllowInternalOutbound: Creating...
azurerm_network_interface.main[1]: Creating...
azurerm_lb.main: Still creating... [10s elapsed]
azurerm_network_security_rule.AllowInternalInbound: Creation complete after 2s [id=/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops/providers/Microsoft.Network/networkSecurityGroups/c1-prj-nsg/securityRules/AllowInternalInbound]
azurerm_network_security_rule.AllowInternalOutbound: Creation complete after 2s [id=/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops/providers/Microsoft.Network/networkSecurityGroups/c1-prj-nsg/securityRules/AllowInternalOutbound]
azurerm_network_security_rule.AllowLoadBalancerInbound: Creation complete after 2s [id=/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops/providers/Microsoft.Network/networkSecurityGroups/c1-prj-nsg/securityRules/AllowLoadBalancerInbound]
azurerm_lb.main: Creation complete after 14s [id=/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops/providers/Microsoft.Network/loadBalancers/c1-prj-lb]
azurerm_lb_backend_address_pool.main: Creating...
azurerm_network_interface.main[1]: Still creating... [10s elapsed]
azurerm_network_interface.main[0]: Still creating... [10s elapsed]
azurerm_network_interface.main[1]: Creation complete after 13s [id=/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops/providers/Microsoft.Network/networkInterfaces/c1-prj-nic1]
azurerm_lb_backend_address_pool.main: Still creating... [10s elapsed]
azurerm_network_interface.main[0]: Still creating... [20s elapsed]
azurerm_lb_backend_address_pool.main: Creation complete after 14s [id=/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops/providers/Microsoft.Network/loadBalancers/c1-prj-lb/backendAddressPools/c1-prj-beap]
azurerm_network_interface.main[0]: Creation complete after 26s [id=/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops/providers/Microsoft.Network/networkInterfaces/c1-prj-nic0]
azurerm_network_interface_backend_address_pool_association.main[0]: Creating...
azurerm_network_interface_backend_address_pool_association.main[1]: Creating...
azurerm_linux_virtual_machine.main[0]: Creating...
azurerm_linux_virtual_machine.main[1]: Creating...
azurerm_network_interface_backend_address_pool_association.main[0]: Creation complete after 2s [id=/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops/providers/Microsoft.Network/networkInterfaces/c1-prj-nic0/ipConfigurations/internal|/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops/providers/Microsoft.Network/loadBalancers/c1-prj-lb/backendAddressPools/c1-prj-beap]
azurerm_network_interface_backend_address_pool_association.main[1]: Creation complete after 2s [id=/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops/providers/Microsoft.Network/networkInterfaces/c1-prj-nic1/ipConfigurations/internal|/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops/providers/Microsoft.Network/loadBalancers/c1-prj-lb/backendAddressPools/c1-prj-beap]
azurerm_linux_virtual_machine.main[1]: Still creating... [10s elapsed]
azurerm_linux_virtual_machine.main[0]: Still creating... [10s elapsed]
azurerm_linux_virtual_machine.main[0]: Still creating... [20s elapsed]
azurerm_linux_virtual_machine.main[1]: Still creating... [20s elapsed]
azurerm_linux_virtual_machine.main[1]: Still creating... [30s elapsed]
azurerm_linux_virtual_machine.main[0]: Still creating... [30s elapsed]
azurerm_linux_virtual_machine.main[0]: Still creating... [40s elapsed]
azurerm_linux_virtual_machine.main[1]: Still creating... [40s elapsed]
azurerm_linux_virtual_machine.main[0]: Creation complete after 49s [id=/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops/providers/Microsoft.Compute/virtualMachines/c1-prj-vm-0]
azurerm_linux_virtual_machine.main[1]: Creation complete after 50s [id=/subscriptions/ae905fde-e5ea-40f0-a6db-35397678cc4c/resourceGroups/Azuredevops/providers/Microsoft.Compute/virtualMachines/c1-prj-vm-1]

Apply complete! Resources: 17 added, 0 changed, 0 destroyed.

Outputs:

name = [
  "c1-prj-vm-0",
  "c1-prj-vm-1",
]
```