# flask-ml-service
A sample Flask application to showcase the Azure Pipeline.

## Environment
Python 3.7
